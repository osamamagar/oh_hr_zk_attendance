## Module <hue_backend_theme>

#### 05.12.2023

#### Version 17.0.1.0.0

##### ADD

- Initial commit for Hue Backend Theme

#### 09.02.2024
#### Version 17.0.1.0.0
#### UPDATE

- The index.html page has been updated to embrace the sleek and modern format of Odoo 17.
